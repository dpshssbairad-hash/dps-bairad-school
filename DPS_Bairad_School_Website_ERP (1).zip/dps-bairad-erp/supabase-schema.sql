-- D.P.S. Bairad School ERP schema. Run in Supabase SQL Editor.
-- RLS is enabled. Never put the service_role key in the browser.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('admin','teacher','student')),
  class_name text,
  admission_no text unique,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create table if not exists public.notices (
 id uuid primary key default gen_random_uuid(), title text not null, body text not null,
 published boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.admissions (
 id uuid primary key default gen_random_uuid(), student_name text not null, father_name text not null,
 mother_name text, class_applied text not null, dob date, mobile text not null, address text,
 created_at timestamptz not null default now()
);
create table if not exists public.attendance (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.profiles(id) on delete cascade,
 attendance_date date not null, status text not null check(status in ('present','absent','late','leave')),
 marked_by uuid references public.profiles(id), created_at timestamptz not null default now(),
 unique(student_id, attendance_date)
);
create table if not exists public.fees (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.profiles(id) on delete cascade,
 fee_title text not null, amount numeric(10,2) not null check(amount >= 0), status text not null default 'pending' check(status in ('pending','paid','partial')),
 paid_on date, receipt_no text, created_at timestamptz not null default now()
);
create table if not exists public.exams (
 id uuid primary key default gen_random_uuid(), exam_name text not null, class_name text not null,
 exam_date date, created_at timestamptz not null default now()
);
create table if not exists public.marks (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.profiles(id) on delete cascade,
 exam_id uuid references public.exams(id) on delete set null, subject text not null,
 marks_obtained numeric(7,2) not null check(marks_obtained >= 0), max_marks numeric(7,2) not null check(max_marks > 0),
 created_at timestamptz not null default now()
);
create table if not exists public.staff (
 id uuid primary key default gen_random_uuid(), full_name text not null, designation text not null,
 phone text, email text, created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.notices enable row level security;
alter table public.admissions enable row level security;
alter table public.attendance enable row level security;
alter table public.fees enable row level security;
alter table public.exams enable row level security;
alter table public.marks enable row level security;
alter table public.staff enable row level security;

-- Profiles: users can read their own profile; admins can read/update all profiles.
drop policy if exists "profile self read" on public.profiles;
create policy "profile self read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
drop policy if exists "admin update profiles" on public.profiles;
create policy "admin update profiles" on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
-- Prevent users from changing their own role: no client insert/update policy for role creation.

-- Notices are public-readable only when published. Admins manage all notices.
drop policy if exists "public read published notices" on public.notices;
create policy "public read published notices" on public.notices for select using (published = true or public.is_admin());
drop policy if exists "admin insert notices" on public.notices;
create policy "admin insert notices" on public.notices for insert to authenticated with check (public.is_admin());
drop policy if exists "admin update notices" on public.notices;
create policy "admin update notices" on public.notices for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin delete notices" on public.notices;
create policy "admin delete notices" on public.notices for delete to authenticated using (public.is_admin());

-- Admission enquiry: anonymous visitors may submit; only admins can read/manage submissions.
drop policy if exists "public submit admissions" on public.admissions;
create policy "public submit admissions" on public.admissions for insert to anon, authenticated with check (length(student_name) between 2 and 100 and length(mobile) = 10);
drop policy if exists "admin read admissions" on public.admissions;
create policy "admin read admissions" on public.admissions for select to authenticated using (public.is_admin());
drop policy if exists "admin manage admissions" on public.admissions;
create policy "admin manage admissions" on public.admissions for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Students see only their own records. Admins/teachers may manage records.
drop policy if exists "attendance own or staff" on public.attendance;
create policy "attendance own or staff" on public.attendance for select to authenticated using (student_id = auth.uid() or public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher'));
drop policy if exists "attendance staff manage" on public.attendance;
create policy "attendance staff manage" on public.attendance for all to authenticated using (public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher')) with check (public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher'));

drop policy if exists "fees own or admin" on public.fees;
create policy "fees own or admin" on public.fees for select to authenticated using (student_id = auth.uid() or public.is_admin());
drop policy if exists "fees admin manage" on public.fees;
create policy "fees admin manage" on public.fees for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "exams authenticated read" on public.exams;
create policy "exams authenticated read" on public.exams for select to authenticated using (true);
drop policy if exists "exams admin manage" on public.exams;
create policy "exams admin manage" on public.exams for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "marks own or staff" on public.marks;
create policy "marks own or staff" on public.marks for select to authenticated using (student_id = auth.uid() or public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher'));
drop policy if exists "marks staff manage" on public.marks;
create policy "marks staff manage" on public.marks for all to authenticated using (public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher')) with check (public.is_admin() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='teacher'));

drop policy if exists "staff authenticated read" on public.staff;
create policy "staff authenticated read" on public.staff for select to authenticated using (true);
drop policy if exists "staff admin manage" on public.staff;
create policy "staff admin manage" on public.staff for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- IMPORTANT: After creating your first account in Authentication > Users,
-- promote that account to admin by running this command with its actual email:
-- update public.profiles set role='admin', full_name='School Administrator'
-- where id=(select id from auth.users where email='YOUR-ADMIN-EMAIL');
