# D.P.S. Higher Secondary School, Bairad — Website + ERP starter

यह React + Vite + Supabase आधारित वेबसाइट प्रोजेक्ट है। इसमें public school website, admission enquiry, notices, secure login, admin notice management और student के attendance/marks/fees देखने का शुरुआती portal शामिल है। Database schema में staff, attendance, fees, exams और marks की tables तथा Row Level Security policies भी हैं।

## 1) कंप्यूटर पर चलाने के लिए
1. Node.js LTS इंस्टॉल करें: https://nodejs.org/
2. इस ZIP को Extract करें और `dps-bairad-erp` folder खोलें।
3. उस folder में Terminal / Command Prompt खोलें।
4. चलाएँ: `npm install`
5. `.env.example` की कॉपी बनाकर उसका नाम `.env` रखें।
6. Supabase Project URL और Publishable/anon key `.env` में भरें।
7. चलाएँ: `npm run dev` और Terminal में दिखा local URL Chrome में खोलें।
8. Publish से पहले `npm run build` चलाएँ।

## 2) Supabase सेटअप
1. https://supabase.com पर Free account बनाकर New Project बनाएँ। Database password सुरक्षित रखें।
2. Project Dashboard → SQL Editor → New query खोलें।
3. इस folder की `supabase-schema.sql` पूरी फाइल paste करके Run करें।
4. Project Settings → API में Project URL और anon/publishable key लें। इन्हें `.env` में रखें। `service_role` / secret key कभी frontend या GitHub में न डालें।
5. Authentication → Providers में Email provider enabled रखें। Authentication → Users से पहले administrator user बनाएँ (या sign-up invite करें)।
6. SQL Editor में schema file के अंत में दिया admin promotion SQL चलाएँ, लेकिन `YOUR-ADMIN-EMAIL` को वास्तविक admin email से बदलें।
7. Admin को अलग मजबूत password दें। Public sign-up वेबसाइट में उपलब्ध नहीं है। नए student/staff accounts केवल trusted admin प्रक्रिया से बनाएँ।

## 3) Netlify पर Free publish
1. https://app.netlify.com पर account बनाएँ।
2. इस project folder को GitHub repository में push करें (या Netlify में supported manual deploy flow अपनाएँ)।
3. Netlify → Add new site → Import an existing project → GitHub repository चुनें।
4. Build command `npm run build`, Publish directory `dist` रखें।
5. Site configuration → Environment variables में `VITE_SUPABASE_URL` और `VITE_SUPABASE_ANON_KEY` जोड़ें।
6. Deploy करें। Netlify आपको `your-site-name.netlify.app` URL देगा जिसे Chrome में खोला जा सकता है।
7. बाद में code बदलने पर GitHub में push करें; Netlify फिर deploy करेगा।

## 4) ध्यान देने योग्य बातें
- Free hosting और database की usage limits होती हैं। Supabase Free project inactivity पर pause हो सकता है; Netlify Free में monthly usage-credit limit है। बड़े/नियमित स्कूल संचालन के लिए paid plan, backups और support की जरूरत पड़ सकती है।
- इस starter में Admission enquiry, Notices, Email/password login, Admin notice CRUD और student record read views जुड़े हुए हैं। Attendance/fees/exam/staff के database tables और access policies मौजूद हैं; इनके लिए full admin entry screens, receipt/PDF generation, bulk import, password reset, audit logs, backup/restore और production QA अगले development चरण में जोड़ने होंगे।
- Real student data डालने से पहले school approval, privacy notice, consent, data retention, backups और security review पूरा करें। सार्वजनिक पेज पर छात्र की निजी जानकारी न दिखाएँ।
- Official phone, email, logo, principal/staff names, photos, timings और affiliation details अभी placeholder/omitted हैं; प्रकाशित करने से पहले verified details भरें।
- यह MP Board school website है, MPBSE की official website नहीं। किसी सरकारी affiliation/accreditation claim को verification के बिना न जोड़ें।
